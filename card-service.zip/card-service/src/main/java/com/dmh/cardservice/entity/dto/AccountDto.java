package com.dmh.cardservice.entity.dto;

import lombok.Data;

@Data
public class AccountDto {
    private Long id;

}
