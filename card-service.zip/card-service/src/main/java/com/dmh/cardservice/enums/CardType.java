package com.dmh.cardservice.enums;


public enum CardType {
    CREDIT,
    DEBIT
}
