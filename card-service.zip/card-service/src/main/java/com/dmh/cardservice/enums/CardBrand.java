package com.dmh.cardservice.enums;
public enum CardBrand {
    VISA, MASTERCARD, AMEX, UNKNOWN
}