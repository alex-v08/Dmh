package com.dmh.cardservice.entity;

public enum CardStatus {
    ACTIVE,
    INACTIVE
}
